﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Allatkereskedes
{
    class Amphibian : Animal
    {
        public Amphibian(int age, string gender, string species)
        {
            this.age = age;
            this.gender = gender;
            this.species = species;
        }
    }
}
