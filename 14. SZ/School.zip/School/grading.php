<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grading</title>
</head>
<body>
    <form method="POST" action="includes/grade.inc.php">
        <?php
            require("includes/filloptions.inc.php");
        ?>
        <label>Grade: </label>
        <select name="grade">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
        </select>
        <br>
        <button type="submit">Submit</button>
    </form>
    <br>
    <form method="POST" action="stats.php">
        <?php
            require("includes/fillname.inc.php");
        ?>
        <button type="submit">Statistics</button>
    </form>
</body>
</html>