<?php
require("connect.php");

$query = "SELECT name, id FROM students";

$rows = mysqli_query($con, $query);

echo "<label>Student: </label><select name='student'>";

while ($result = mysqli_fetch_assoc($rows)) {
    echo "<option value=" . $result['id'] . ">" . $result['name'] . "</option>";
}

echo "</select><br>";