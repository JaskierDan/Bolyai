<?php
require("connect.php");

if (isset($_POST['student']) && isset($_POST['grade']) && isset($_POST['subject'])) {
    $student = $_POST['student'];
    $grade = $_POST['grade'];
    $subject = $_POST['subject'];

    $query = "INSERT INTO grades(id, grade, subject_id, student_id) VALUES(NULL, '$grade', '$subject', '$student')";

    mysqli_query($con, $query);

    header("Location: ../grading.php");
} else {
    header("Location: ../grading.php");
}
