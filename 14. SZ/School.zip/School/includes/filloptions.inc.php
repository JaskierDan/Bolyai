<?php
require("connect.php");

$query = "SELECT id, name, class FROM students";

$rows = mysqli_query($con, $query);

echo "<label>Student: </label><select name='student'>";

while ($result = mysqli_fetch_assoc($rows)) {
    echo "<option value=" . $result['id'] . ">" . $result['name'] . "</option>";
}

echo "</select><br>";

$rows1 = mysqli_query($con, $query);

echo "<label>Class: </label><select name='class'>";

while ($result = mysqli_fetch_assoc($rows1)) {
    echo "<option value=" . $result['id'] . ">" . $result['class'] . "</option>";
}

echo "</select><br>";

$query1 = "SELECT * FROM subjects";

$rows2 = mysqli_query($con, $query1);

echo "<label>Subject: </label><select name='subject'>";

while ($result = mysqli_fetch_assoc($rows2)) {
    echo "<option value=" . $result['id'] . ">" . $result['name'] . "</option>";
}

echo "</select><br>";