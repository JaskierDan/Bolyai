<?php

$server = "localhost";
$database = "school";
$pwd = "";
$user = "root";

$con = mysqli_connect($server, $user, $pwd, $database) or die("Connection error!");