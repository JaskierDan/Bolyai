<?php
require("connect.php");

if(isset($_POST['pwd'])){
    $query = "SELECT password FROM admin";

    $rows = mysqli_query($con, $query);

    $pwd = mysqli_fetch_assoc($rows);

    if(password_verify($_POST['pwd'], $pwd['password'])){
        header("Location: ../grading.php");
    }
    else{
        echo "<script>alert('Helytelen jelszó!');window.location='../index.html'</script>";        
    }
}
else{
    header("Location: ../index.html");
}
