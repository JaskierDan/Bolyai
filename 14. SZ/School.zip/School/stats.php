<?php
require("includes/connect.php");

if(isset($_POST['student'])){
    $id = $_POST['student'];
    $query = "SELECT grades.grade, subjects.name AS 'subject_name' FROM grades, subjects WHERE grades.student_id = '$id' AND grades.subject_id = subjects.id";

    $rows = mysqli_query($con, $query);

    while($result = mysqli_fetch_assoc($rows)){
        echo "Grade: ".$result['grade']." Subject: ".$result['subject_name']."<br>";
    }
}
else{
    header("Location: grading.php");
}