﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MintaVizsga
{
    /// <summary>
    /// Interaction logic for EditEntry.xaml
    /// </summary>
    public partial class EditEntry : Window
    {
        private int id;
        public EditEntry(int id)
        {                        
            InitializeComponent();
            this.id = id;
        }

        private void Add_wh_Click(object sender, RoutedEventArgs e)
        {
            Connection conn = new Connection();
            conn.EditWarehouse(wh_name.Text, id);
            this.Close();
        }
    }
}
