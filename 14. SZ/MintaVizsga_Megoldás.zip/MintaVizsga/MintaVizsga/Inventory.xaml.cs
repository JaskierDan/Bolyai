﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MintaVizsga
{
    /// <summary>
    /// Interaction logic for Inventory.xaml
    /// </summary>
    public partial class Inventory : Window
    {
        private int id;
        private int item_id;

        Connection conn = new Connection();
        public Inventory(int id)
        {
            InitializeComponent();
            this.id = id;
            conn.FillItemList(Item_List, id);
        }

        private void Add_Item_Click(object sender, RoutedEventArgs e)
        {
            if(Item_Name.Text == "" || Item_Amount.Text == "")
            {
                MessageBox.Show("Valamelyik adatot nem adtad meg!");
            }
            else
            {
                conn.AddItem(Item_Name, Item_Amount, id);
                Item_List.ItemsSource = null;
                conn.FillItemList(Item_List, id);
            }
        }

        private void Delete_Item_Click(object sender, RoutedEventArgs e)
        {
            if(item_id > 0)
            {
                conn.DeleteItem(item_id);
                Item_List.ItemsSource = null;
                conn.FillItemList(Item_List, id);
            }
            else
            {
                MessageBox.Show("Kérem válasszon egy lista elemet!");
            }
        }

        private void Item_List_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            item_id = Convert.ToInt32(Item_List.SelectedValue);
        }

        private void Edit_Item_Click(object sender, RoutedEventArgs e)
        {
            if (item_id > 0)
            {
                EditInventory winform = new EditInventory(item_id);
                winform.ShowDialog();
                Item_List.ItemsSource = null;
                conn.FillItemList(Item_List, id);
            }
            else
            {
                MessageBox.Show("Kérem válasszon egy lista elemet!");
            }
        }
    }
}
