﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MintaVizsga
{
    class Connection
    {
        
        MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=warehouse");
        

        private void Connect()
        {
            try {
                conn.Open();
            }
            catch(MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        public void FillWhList(ListBox lb)
        {
            Connect();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id, name FROM warehouses", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns[1].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
            conn.Close();
        }

        public void FillItemList(ListBox lb, int id)
        {
            Connect();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id, CONCAT_WS(' ', name, amount) AS ossz FROM inventory WHERE warehouse_id=" + id + "", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns["ossz"].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
            conn.Close();
        }

        public void AddWarehouse(string name)
        {
            Connect();
            string query = String.Format("INSERT INTO warehouses(id, name) VALUES(NULL, '{0}')", name);
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void EditWarehouse(string name, int id)
        {
            Connect();
            string query = String.Format("UPDATE warehouses SET name='{0}' WHERE id={1}", name, id);
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void EditItem(string name, string amount, int id)
        {
            Connect();
            string query = String.Format("UPDATE inventory SET name='{0}', amount={1} WHERE id={2}", name, amount, id);
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void DeleteWarehouse(int id)
        {
            Connect();
            string query = String.Format("DELETE FROM warehouses WHERE id={0}", id);
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void DeleteItem(int id)
        {
            Connect();
            string query = String.Format("DELETE FROM inventory WHERE id={0}", id);
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void AddItem(TextBox name, TextBox amount, int wh_id)
        {
            Connect();
            string query = String.Format("INSERT INTO inventory(id, warehouse_id, name, amount) VALUES(NULL, {0}, '{1}', {2})", wh_id, name.Text, Convert.ToInt32(amount.Text));
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

    }
}
