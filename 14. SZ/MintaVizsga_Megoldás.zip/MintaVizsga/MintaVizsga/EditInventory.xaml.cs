﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MintaVizsga
{
    /// <summary>
    /// Interaction logic for EditInventory.xaml
    /// </summary>
    public partial class EditInventory : Window
    {
        private int id;
        public EditInventory(int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Connection conn = new Connection();
            if(Item_Name.Text == "" || Item_Amount.Text == "")
            {
                MessageBox.Show("Valamelyik adatot nem adtad meg!");
            }
            else
            {
                conn.EditItem(Item_Name.Text, Item_Amount.Text, id);
            }
        }
    }
}
