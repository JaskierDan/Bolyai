﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MintaVizsga
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int id;
        
        Connection conn = new Connection();
        public MainWindow()
        {
            InitializeComponent();        
            conn.FillWhList(wh_list);
        }

        private void new_entry_Click(object sender, RoutedEventArgs e)
        {
            NewEntry winform = new NewEntry();
            winform.ShowDialog();
            wh_list.ItemsSource = null;
            conn.FillWhList(wh_list);
        }

        private void wh_list_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            id = Convert.ToInt32(wh_list.SelectedValue);           
        }

        private void edit_wh_Click(object sender, RoutedEventArgs e)
        {
            EditEntry winform = new EditEntry(id);
            winform.ShowDialog();
            wh_list.ItemsSource = null;
            conn.FillWhList(wh_list);
            id = 0;
        }

        private void wh_delete_Click(object sender, RoutedEventArgs e)
        {
            conn.DeleteWarehouse(id);
            wh_list.ItemsSource = null;
            conn.FillWhList(wh_list);
            id = 0;
        }

        private void view_inv_Click(object sender, RoutedEventArgs e)
        {
            if(id > 0)
            {
                Inventory winform = new Inventory(id);
                winform.ShowDialog();
                id = 0;
            }
            else
            {
                MessageBox.Show("Kérem válasszon egy lista elemet!");
            }
        }
    }
}
