﻿using System;

namespace Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dict<string> a = new Dict<string>("1", "Alma");
            a.Insert("1");
            a.Insert("2", "Körte");
            a.Insert("2", "Paradicsom");
            a.Insert("3");
            Console.WriteLine($"Üres: {a.Ures()}");
            Console.WriteLine($"Elemszám: {a.Elemszam()}");
            a.Remove("1");
            Console.WriteLine($"Elemszám: {a.Elemszam()}");
            a.Print();
            Console.WriteLine();

            Dict<int> b = new Dict<int>("1", 3);
            b.Insert("2", 2);
            b.Insert("2");
            Console.WriteLine($"Üres: {b.Ures()}");
            Console.WriteLine($"Elemszám: {b.Elemszam()}");
            b.Remove("2");
            Console.WriteLine($"Elemszám: {b.Elemszam()}");
            b.Print();
            Console.WriteLine();
            
            Dict<int> c = new Dict<int>(b);
            c.Print();
        }
    }
}
