﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dictionary
{
    class Dict<Type>
    {
        private List<string> key = new List<string>();
        private List<Type> val = new List<Type>();
        public Dict()
        {
            key.Add("");
            val.Add(default(Type));
        }

        public Dict(string key)
        {
            this.key.Add(key);
            val.Add(default(Type));
        }

        public Dict(Dict<Type> a)
        {
            key = a.key;
            val = a.val;
        }

        public Dict(string key, Type val)
        {
            this.key.Add(key);
            this.val.Add(val);
        }

        public int Elemszam()
        {
            return key.Count;
        }

        public bool Ures()
        {
            return (key.Count == 0);
        }

        public void Insert(string key)
        {
            this.key.Add(key);
            val.Add(default(Type));
        }

        public void Insert(string key, Type val)
        {
            this.key.Add(key);
            this.val.Add(val);
        }

        public void Remove(string key)
        {
            if (this.key.Contains(key))
            {
                for (int i = this.key.Count - 1; i > -1; --i)
                {
                    if(this.key[i] == key)
                    {
                        this.key.RemoveAt(i);
                        val.RemoveAt(i);
                    }
                }
            }
            else
            {
                Console.WriteLine("Nincs ilyen kulcs!");
            }
        }

        public void Print()
        {
            for (int i = 0; i < key.Count; ++i)
            {
                Console.WriteLine(key[i] + " " + val[i]);
            }
        }
    }
}
