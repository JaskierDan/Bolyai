﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace WPFGyak3
{
    class Connection
    {
        private static MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=wpfgyak3");        

        private static void Connect()
        {
            try
            {
                conn.Open();
            }
            catch(MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void Insert(TextBox tb, PasswordBox pb)
        {
            Connect();
            MySqlCommand cmd = new MySqlCommand("INSERT INTO users(id, username, password) VALUES(NULL, '" + tb.Text + "', '" + Encryption.Encrypt(pb.Password.ToString()) + "')", conn);
            if(tb.Text!=null && pb.Password.ToString() != null)
            {
                cmd.ExecuteNonQuery();
            }
            else
            {
                MessageBox.Show("Please fill both fields!");
            }
            conn.Close();
        }

        public static void CheckUser(TextBox tb, PasswordBox pb)
        {
            Connect();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM users WHERE username='" + tb.Text + "' AND password='" + Encryption.Encrypt(pb.Password.ToString()) + "'", conn);
            MySqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read() && rd.HasRows)
            {
                MessageBox.Show("Successful login!");
            }
            else
            {
                MessageBox.Show("Unsuccessful login!");
            }
            rd.Close();
            conn.Close();
        }
    }
}
