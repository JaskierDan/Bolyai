<?php
$conn = new mysqli('localhost', 'root', '', 'bolt')
 or die("Can't connect!");
