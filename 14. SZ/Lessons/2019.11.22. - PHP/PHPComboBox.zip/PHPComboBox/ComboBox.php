<?php

require "connection.php";

$query = "SELECT id, nev FROM reszlegek";
$result = $conn->query($query);
while($row=$result->fetch_assoc()){
    echo "
        <option value='".$row['id']."'>".$row['nev']."</option>
        ";
}
