-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2019. Nov 22. 10:52
-- Kiszolgáló verziója: 10.1.34-MariaDB
-- PHP verzió: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `bolt`
--
CREATE DATABASE IF NOT EXISTS `bolt` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE `bolt`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `keszletek`
--

CREATE TABLE `keszletek` (
  `id` int(11) NOT NULL,
  `reszlegID` int(11) NOT NULL,
  `nev` tinytext COLLATE utf8_hungarian_ci NOT NULL,
  `db` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `keszletek`
--

INSERT INTO `keszletek` (`id`, `reszlegID`, `nev`, `db`) VALUES
(1, 1, 'Alma', 200),
(2, 2, 'Mosószer', 150),
(3, 1, 'Körte', 130),
(4, 2, 'Szivacs', 300);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `reszlegek`
--

CREATE TABLE `reszlegek` (
  `id` int(11) NOT NULL,
  `nev` tinytext COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `reszlegek`
--

INSERT INTO `reszlegek` (`id`, `nev`) VALUES
(1, 'élelmiszer'),
(2, 'háztartás');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `keszletek`
--
ALTER TABLE `keszletek`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reszlegID` (`reszlegID`);

--
-- A tábla indexei `reszlegek`
--
ALTER TABLE `reszlegek`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `keszletek`
--
ALTER TABLE `keszletek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `reszlegek`
--
ALTER TABLE `reszlegek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `keszletek`
--
ALTER TABLE `keszletek`
  ADD CONSTRAINT `keszletek_ibfk_1` FOREIGN KEY (`reszlegID`) REFERENCES `reszlegek` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
