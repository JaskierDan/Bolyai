<?php

require "connection.php";

$query = "SELECT id, CONCAT_WS(' ', nev, db) as ossz FROM keszletek";
$result = $conn->query($query);
while($row=$result->fetch_assoc()){
    echo "
        <option value='".$row['id']."'>".$row['ossz']."</option>
        ";
}
