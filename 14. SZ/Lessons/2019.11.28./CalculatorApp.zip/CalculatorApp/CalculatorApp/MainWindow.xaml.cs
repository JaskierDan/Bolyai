﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CalculatorApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Connection conn = new Connection();
            conn.ComboBoxFill(cb);
            cb.SelectedIndex = 0;
        }

        private bool skipTextChange = false;

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SymbolTxt.Text = "+";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SymbolTxt.Text = "-";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            SymbolTxt.Text = "*";
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            SymbolTxt.Text = "/";
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Users winform = new Users();
            winform.ShowDialog();
            Num1.Text = "";
            Num2.Text = "";
            SymbolTxt.Text = "";
            ResultTxt.Text = "";
            skipTextChange = true;
        }

        private void TestIfNum(TextBox tb)
        {
            try
            {
                int a = int.Parse(tb.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("You didn't use a number! Error: " + ex.Message.ToString());
                skipTextChange = true;
                tb.Text = "";
                skipTextChange = false;
            }
        }

        private void Num1_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (skipTextChange) { return; }
            TestIfNum(Num1);
        }

        private void Num2_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (skipTextChange) { return; }
            TestIfNum(Num2);
        }

        private void EqualBtn_Click(object sender, RoutedEventArgs e)
        {
            Connection conn = new Connection();
            if(Num1.Text != "" && Num2.Text!="" && SymbolTxt.Text != "")
            {                
                int r = conn.CalculateResult(SymbolTxt, Num1, Num2, cb);
                ResultTxt.Text = r.ToString();
            }
            else
            {
                MessageBox.Show("One of the fields is empty or an operator was not selected!");
            }
            skipTextChange = true;
        }
    }
}
