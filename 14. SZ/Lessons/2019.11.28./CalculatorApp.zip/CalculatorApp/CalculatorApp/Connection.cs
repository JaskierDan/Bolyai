﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;

namespace CalculatorApp
{
    class Connection
    {
        private MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=calculatorwpf");

        private void Connect()
        {
            try
            {
                conn.Open();
            }
            catch(MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        public void ComboBoxFill(ComboBox cb)
        {
            Connect();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id, name FROM users", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cb.ItemsSource = ds.Tables[0].DefaultView;
            cb.DisplayMemberPath = ds.Tables[0].Columns[1].ToString();
            cb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
            conn.Close();
        }

        public void ListBoxFill(ListBox lb, ComboBox cb)
        {
            Connect();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id, calculation FROM history WHERE userID='" + cb.SelectedValue + "'", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns[1].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
            conn.Close();
        }

        public int CalculateResult(TextBox sym, TextBox num1, TextBox num2, ComboBox cb)
        {
            int result = 0;
            int a = int.Parse(num1.Text);
            int b = int.Parse(num2.Text);

            switch (sym.Text)
            {
                case "+":
                    result = a + b;
                    break;

                case "-":
                    result = a - b;
                    break;

                case "*":
                    result = a * b;
                    break;

                case "/":
                    result = a / b;
                    break;
            }
            InsertHistory(a, sym, b, result, cb);
            return result;
        }

        private void InsertHistory(int a, TextBox tb, int b, int result, ComboBox cb)
        {
            Connect();
            string sql = String.Format("INSERT INTO history(id, userID, calculation) VALUES(NULL, '{0}', '{1} {2} {3} = {4}')", cb.SelectedValue, a, tb.Text, b, result);
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}
