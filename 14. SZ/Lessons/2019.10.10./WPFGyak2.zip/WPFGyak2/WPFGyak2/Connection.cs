﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;

namespace WPFGyak2
{
    class Connection
    {
        private static MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=wpfgyak");

        public static void Connect() {
            try {
                conn.Open();
            }
            catch(MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void CloseConn()
        {
            conn.Close();
        }

        public static void FillComboBox(ComboBox cb) {
            string cmd = "SELECT CONCAT_WS(' ', id, fName, lName) as ossz FROM data";
            MySqlDataAdapter da = new MySqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cb.ItemsSource = ds.Tables[0].DefaultView;
            cb.DisplayMemberPath = ds.Tables[0].Columns[0].ToString();
            cb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
        }

        public static void FillListBox(ListBox lb) {
            string cmd = "SELECT CONCAT_WS(' ', id, fName, lName) as ossz FROM data";
            MySqlDataAdapter da = new MySqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns[0].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
        }
    }
}
